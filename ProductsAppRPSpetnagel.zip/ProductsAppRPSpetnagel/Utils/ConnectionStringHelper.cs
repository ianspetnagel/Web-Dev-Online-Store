﻿namespace ProductsAppRPSpetnagel.Utils
{
    public class ConnectionStringHelper
    {
        public static string CONNSTR_SQL { get; set; }
        public static string CONNSTR_MYSQL { get; set; }
    


    }
}
