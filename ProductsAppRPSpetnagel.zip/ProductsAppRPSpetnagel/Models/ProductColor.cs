﻿namespace ProductsAppRPSpetnagel.Models
{
    public class ProductColor
    {
        public int ColorId { get; set; }
        public string ColorName { get; set; } = null!;
    }
}
