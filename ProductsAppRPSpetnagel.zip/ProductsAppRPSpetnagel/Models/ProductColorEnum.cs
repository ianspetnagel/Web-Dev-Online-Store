﻿namespace ProductsAppRPSpetnagel.Models
{
    //I Chnaged this to have public enum
    public enum ProductColorEnum
    {
        RED,
        GREEN,
        BLUE
    }
}
